﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppBoteco.Classes;

namespace AppBoteco
{
    public partial class FrmFuncionario : Form
    {
        public FrmFuncionario()
        {
            InitializeComponent();
        }

        private void FrmFuncionario_Load(object sender, EventArgs e)
        {
            Funcionario funcionario = new Funcionario();
            List<Funcionario> funcionarios = funcionario.listafuncionario();
            dgvFunc.DataSource = funcionarios;
            btnEditar.Enabled = false;
            btnExcluir.Enabled = false;
            this.ActiveControl = txtNome;
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            if (txtNome.Text == "" || mtxtCpf.Text == "" || mtxtCelular.Text == "" || txtCargo.Text == "" || mtxtCep.Text == "" || txtEndereco.Text == "" || txtBairro.Text == "" || txtCidade.Text == "")
            {
                MessageBox.Show("Por favor, preencha todos os campos!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                Funcionario funcionario = new Funcionario();
                if (funcionario.RegistroRepetido(mtxtCpf.Text) == true)
                {
                    MessageBox.Show("Funcionário já existe em nossa base de dados!", "Funcionário Repetido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtNome.Text = "";
                    mtxtCpf.Text = "";
                    mtxtCelular.Text = "";
                    txtCargo.Text = "";
                    mtxtCep.Text = "";
                    txtEndereco.Text = "";
                    txtBairro.Text = "";
                    txtCidade.Text = "";
                    return;
                }
                else
                {
                    funcionario.Inserir(txtNome.Text, mtxtCpf.Text, mtxtCelular.Text, txtCargo.Text, mtxtCep.Text, txtEndereco.Text, txtBairro.Text, txtCidade.Text);
                    MessageBox.Show("Funcionário Inserido com sucesso!", "Inserção", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    List<Funcionario> funcionarios = funcionario.listafuncionario();
                    dgvFunc.DataSource = funcionarios;
                    txtNome.Text = "";
                    mtxtCpf.Text = "";
                    mtxtCelular.Text = "";
                    txtCargo.Text = "";
                    mtxtCep.Text = "";
                    txtEndereco.Text = "";
                    txtBairro.Text = "";
                    txtCidade.Text = "";
                    this.txtNome.Focus();
                }
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro - Inserção", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                int Id = Convert.ToInt32(txtId.Text.Trim());
                Funcionario funcionario = new Funcionario();
                funcionario.Atualizar(Id, txtNome.Text, mtxtCpf.Text, mtxtCelular.Text, txtCargo.Text, mtxtCep.Text, txtEndereco.Text, txtBairro.Text, txtCidade.Text);
                MessageBox.Show("Funcionário atualizado com sucesso!", "Atualizar", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Funcionario> funcionarios = funcionario.listafuncionario();
                dgvFunc.DataSource = funcionarios;
                txtId.Text = "";
                txtNome.Text = "";
                mtxtCelular.Text = "";
                mtxtCpf.Text = "";
                txtCargo.Text = "";
                mtxtCep.Text = "";
                txtEndereco.Text = "";
                txtBairro.Text = "";
                txtCidade.Text = "";
                this.ActiveControl = txtNome;
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro - Inserção", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            if (txtId.Text == "")
            {
                MessageBox.Show("Por favor, digite um ID para localizar!", "Sem ID", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                return;
            }
            try
            {
                int Id = Convert.ToInt32(txtId.Text.Trim());
                Funcionario funcionario = new Funcionario();
                funcionario.Localizar(Id);
                txtNome.Text = funcionario.nome;
                mtxtCelular.Text = funcionario.celular;
                mtxtCpf.Text = funcionario.cpf;
                txtCargo.Text = funcionario.cargo;
                mtxtCep.Text = funcionario.cep;
                txtEndereco.Text = funcionario.endereco;
                txtBairro.Text = funcionario.bairro;
                txtCidade.Text = funcionario.cidade;
                if (txtNome.Text != null)
                {
                    btnEditar.Enabled = true;
                    btnExcluir.Enabled = true;
                }
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro - Inserção", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                int Id = Convert.ToInt32(txtId.Text.Trim());
                Funcionario funcionario = new Funcionario();
                funcionario.Excluir(Id);
                MessageBox.Show("Funcionário excluído com sucesso!", "Exclusão", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Funcionario> funcionarios = funcionario.listafuncionario();
                dgvFunc.DataSource = funcionarios;
                txtId.Text = "";
                txtNome.Text = "";
                mtxtCelular.Text = "";
                mtxtCpf.Text = "";
                txtCargo.Text = "";
                mtxtCep.Text = "";
                txtEndereco.Text = "";
                txtBairro.Text = "";
                txtCidade.Text = "";
                this.ActiveControl = txtNome;
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro - Inserção", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
